(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['planettraining:material-design-icons-font'] = {};

})();
