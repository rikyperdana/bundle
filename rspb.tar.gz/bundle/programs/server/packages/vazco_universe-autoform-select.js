(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['vazco:universe-autoform-select'] = {};

})();
