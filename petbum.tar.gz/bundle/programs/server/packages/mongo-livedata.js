(function () {



/* Exports */
Package._define("mongo-livedata");

})();
