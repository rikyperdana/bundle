/* Imports for global scope */

Mongo = Package.mongo.Mongo;
ReactiveVar = Package['reactive-var'].ReactiveVar;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
prelude = Package['zenkogu:livescript-compiler'].prelude;
lodash = Package['stevezhu:lodash'].lodash;
_ = Package['stevezhu:lodash']._;
AutoForm = Package['aldeed:autoform'].AutoForm;
moment = Package['momentjs:moment'].moment;
Roles = Package['alanning:roles'].Roles;
numeral = Package['numeral:numeral'].numeral;
exportcsv = Package['lfergon:exportcsv'].exportcsv;
saveAs = Package['lfergon:exportcsv'].saveAs;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
DDP = Package['ddp-client'].DDP;
LaunchScreen = Package['launch-screen'].LaunchScreen;
meteorInstall = Package.modules.meteorInstall;
meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
Promise = Package.promise.Promise;
SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
MongoObject = Package['aldeed:simple-schema'].MongoObject;
Accounts = Package['accounts-base'].Accounts;
Autoupdate = Package.autoupdate.Autoupdate;
Reload = Package.reload.Reload;

